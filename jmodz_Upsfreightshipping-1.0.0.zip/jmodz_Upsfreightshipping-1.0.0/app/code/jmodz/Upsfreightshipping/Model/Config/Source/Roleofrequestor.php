<?php
namespace jmodz\Upsfreightshipping\Model\Config\Source;

class Roleofrequestor implements \Magento\Framework\Option\ArrayInterface
{
 
public function getCode($type, $code = '') {
		$codes = array (
            'method'=>array(
                'STANDARD' => 'Standard Service (commercial delivery)',
		),
			'freight_class' => array (
				'50' => '50',
				'55' => '55',
				'60' => '60',
				'65' => '65',
				'70' => '70',
				'77.5' => '77.5',
				'85' => '85',
				'92.5' => '92.5',
				'100' => '100',
				'110' => '110',
				'125' => '125',
				'150' => '150',
				'175' => '175',
				'200' => '200',
				'250' => '250',
				'300' => '300',
				'400' => '400',
				'500' => '500',
		),
		'package_type' => array (
				'BAG' => 'Bag',
				'BAL' => 'Bale',
				'BAR' => 'Barrel',
				'BDL' => 'Bundle',
				'BIN' => 'Bin',
				'BOX' => 'Box',
				'BSK' => 'Basket',
				'BUN' => 'Bunch',
				'CAB' => 'Cabinet',
				'CAN' => 'Can',
				'CAR' => 'Carrier',
				'CAS' => 'Case',
				'CBY' => 'Carboy',
				'CON' => 'Container',
				'CRT' => 'Crate',
				'CSK' => 'Cask',
				'CTN' => 'Carton',
				'CYL' => 'Cylinder',
				'DRM' => 'Drum',
				'LOO' => 'Loose',
				'OTH' => 'Other',
				'PAL' => 'Pail',
				'PCS' => 'Pieces',
				'PKG' => 'Package',
				'PLN' => 'Pipe Line',
				'PLT' => 'Pallet',
				'RCK' => 'Rack',
				'REL' => 'Reel',
				'ROL' => 'Roll',
				'SKD' => 'Skid',
				'SPL' => 'Spool',
				'TBE' => 'Tube',
				'TNK' => 'Tank',
				'UNT' => 'Unit',
				'VPK' => 'Van Pack',
				'WRP' => 'Wrapped',
		),
		'requester_type' => array (
				'10' => 'Prepaid (requires bill to address)',
				'20' => 'Bill to Consignee (requires bill to address)',
				'30' => 'Bill to Third Party (requires bill to address)',
				'40' => 'Freight Collect',
		//'billto'    => 'Bill To (requires a Bill To address)',
		),
		);

		if (!isset ($codes[$type])) {
			//            throw Mage::exception('Mage_Shipping', Mage::helper('usa')->__('Invalid UPS CGI code type: %s', $type));
			return false;
		}
		elseif ('' === $code) {
			return $codes[$type];
		}

		if (!isset ($codes[$type][$code])) {
			//            throw Mage::exception('Mage_Shipping', Mage::helper('usa')->__('Invalid UPS CGI code for type %s: %s', $type, $code));
			return false;
		} else {
			return $codes[$type][$code];
		}
	}

 public function toOptionArray()
 {

 	/*$objectManager = \Magento\Framework\App\ObjectManager::getInstance();

	$fedFreight = $objectManager->create('jmodz\Upsfreightshipping\Model\Carrier\Upsfreight');*/

	$arr = [];
        foreach ($this->getCode('requester_type') as $k=>$v) {
            $arr[] = ['value'=>$k, 'label'=>$v];
        }
        //print_r($arr);die;
        return $arr;
  /*return [
    ['value' => 'grid', 'label' => __('Grid Only')],
    ['value' => 'list', 'label' => __('List Only')],
    ['value' => 'grid-list', 'label' => __('Grid (default) / List')],
    ['value' => 'list-grid', 'label' => __('List (default) / Grid')]
  ];*/
 }
}